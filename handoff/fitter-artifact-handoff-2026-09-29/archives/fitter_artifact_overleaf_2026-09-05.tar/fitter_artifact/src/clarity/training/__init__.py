"""Controller training implementations."""
