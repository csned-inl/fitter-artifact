"""Discretization validation tests."""
